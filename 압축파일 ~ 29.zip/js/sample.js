/*
   별도로 작성된 자바스크립트 샘플
*/

function samp(){
    window.alert("별도로 작성된 samp()함수 실행됨");
}